package com.iihtproject.sellerservice.enums;

public enum ProductCategory {
    PAINTING, SCULPTOR, ORNAMENT
}
