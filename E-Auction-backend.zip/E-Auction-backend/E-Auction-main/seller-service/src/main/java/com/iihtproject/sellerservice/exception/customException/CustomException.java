package com.iihtproject.sellerservice.exception.customException;

public class CustomException extends RuntimeException{
    public CustomException(String str){
        super(str);
    }
}
