package com.iihtproject.buyerservice.exception.customException;

public class CustomException extends RuntimeException{
    public CustomException(String str){
        super(str);
    }
}